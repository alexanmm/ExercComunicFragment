package br.com.digitalhouse.exerccomunicfragment.interfaces;

public interface Comunicator {

    public void receberMensagem(String nomeCor);

}
